# Docker compose container down
docker-compose -f docker-compose.frontend.yml down

# Docker image remove
docker-compose -f docker-compose.frontend.yml down --rmi local