# Docker compose image creation
docker-compose -f docker-compose.gpt.yml build --no-cache

# Docker compose container run
docker-compose -f docker-compose.gpt.yml up -d