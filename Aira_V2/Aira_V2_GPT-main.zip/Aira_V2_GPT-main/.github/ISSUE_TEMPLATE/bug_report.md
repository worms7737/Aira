---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

---
name: "🐞 버그 리포트 (Bug Report)"
about: "발생한 버그를 신고하세요"
title: "[Bug] 버그 요약"
labels: bug
assignees: ''
---

## 🐞 문제 설명 (What?)
- 어떤 문제가 발생했나요?

---

## ❓ 문제 이유 (Why?)
- 문제가 왜 발생했나요?

---

## 💡 해결 방법 (How?)
- 문제를 어떻게 해결할 것인가요?

---
## 🚨 To-Do
- [] Task 1
- [] Task 2

---

## 💻 재현 단계 (선택)
- 문제를 재현하는 방법:
1. [ ] 첫 번째 단계
2. [ ] 두 번째 단계
3. [ ] 오류 발생 시점

---

## 📸 스크린샷 (선택)
- 오류 화면이 있다면 첨부하세요.

---

## 🧩 환경 정보 (선택)
- 운영체제: (예: Windows, macOS)
- 브라우저: (예: Chrome, Firefox)
